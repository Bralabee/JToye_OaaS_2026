pg_dump: last built-in OID is 16383
pg_dump: reading extensions
pg_dump: identifying extension members
pg_dump: reading schemas
pg_dump: reading user-defined tables
pg_dump: reading user-defined functions
pg_dump: reading user-defined types
pg_dump: reading procedural languages
pg_dump: reading user-defined aggregate functions
pg_dump: reading user-defined operators
pg_dump: reading user-defined access methods
pg_dump: reading user-defined operator classes
pg_dump: reading user-defined operator families
pg_dump: reading user-defined text search parsers
pg_dump: reading user-defined text search templates
pg_dump: reading user-defined text search dictionaries
pg_dump: reading user-defined text search configurations
pg_dump: reading user-defined foreign-data wrappers
pg_dump: reading user-defined foreign servers
pg_dump: reading default privileges
pg_dump: reading user-defined collations
pg_dump: reading user-defined conversions
pg_dump: reading type casts
pg_dump: reading transforms
pg_dump: reading table inheritance information
pg_dump: reading event triggers
pg_dump: finding extension tables
pg_dump: finding inheritance relationships
pg_dump: reading column info for interesting tables
pg_dump: finding table default expressions
pg_dump: finding table check constraints
pg_dump: flagging inherited columns in subtables
pg_dump: reading partitioning data
pg_dump: reading indexes
pg_dump: flagging indexes in partitioned tables
pg_dump: reading extended statistics
pg_dump: reading constraints
pg_dump: reading triggers
pg_dump: reading rewrite rules
pg_dump: reading policies
pg_dump: reading row-level security policies
pg_dump: reading publications
pg_dump: reading publication membership of tables
pg_dump: reading publication membership of schemas
pg_dump: reading subscriptions
pg_dump: reading large objects
pg_dump: reading dependency data
pg_dump: saving encoding = UTF8
pg_dump: saving standard_conforming_strings = on
pg_dump: saving search_path = 
pg_dump: dropping POLICY shops shops_rls_policy
pg_dump: dropping POLICY shops_aud shops_aud_select_policy
pg_dump: dropping POLICY shops_aud shops_aud_insert_policy
pg_dump: dropping POLICY products products_rls_policy
pg_dump: dropping POLICY products_aud products_aud_select_policy
pg_dump: dropping POLICY products_aud products_aud_insert_policy
pg_dump: dropping POLICY orders orders_update_policy
pg_dump: dropping POLICY orders orders_select_policy
pg_dump: dropping POLICY orders orders_insert_policy
pg_dump: dropping POLICY orders orders_delete_policy
pg_dump: dropping POLICY orders_aud orders_aud_select_policy
pg_dump: dropping POLICY orders_aud orders_aud_insert_policy
pg_dump: dropping POLICY order_items order_items_update_policy
pg_dump: dropping POLICY order_items order_items_select_policy
pg_dump: dropping POLICY order_items order_items_insert_policy
pg_dump: dropping POLICY order_items order_items_delete_policy
pg_dump: dropping POLICY order_items_aud order_items_aud_select_policy
pg_dump: dropping POLICY order_items_aud order_items_aud_insert_policy
pg_dump: dropping POLICY financial_transactions financial_transactions_rls_policy
pg_dump: dropping POLICY financial_transactions_aud financial_transactions_aud_select_policy
pg_dump: dropping POLICY financial_transactions_aud financial_transactions_aud_insert_policy
pg_dump: dropping POLICY customers customers_update_policy
pg_dump: dropping POLICY customers customers_select_policy
pg_dump: dropping POLICY customers customers_insert_policy
pg_dump: dropping POLICY customers customers_delete_policy
pg_dump: dropping POLICY customers_aud customers_aud_select_policy
pg_dump: dropping POLICY customers_aud customers_aud_insert_policy
pg_dump: dropping FK CONSTRAINT shops fk_shops_tenant
--
-- PostgreSQL database dump
--

\restrict MOFAQiLAqZgwhPBKUj7DtCXofGYuAeVaSa9zDNYLe0EEdIZYION0JBG09Z4YNrA

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

-- Started on 2025-12-31 12:02:49 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS shops_rls_policy ON public.shops;
DROP POLICY IF EXISTS shops_aud_select_policy ON public.shops_aud;
DROP POLICY IF EXISTS shops_aud_insert_policy ON public.shops_aud;
DROP POLICY IF EXISTS products_rls_policy ON public.products;
DROP POLICY IF EXISTS products_aud_select_policy ON public.products_aud;
DROP POLICY IF EXISTS products_aud_insert_policy ON public.products_aud;
DROP POLICY IF EXISTS orders_update_policy ON public.orders;
DROP POLICY IF EXISTS orders_select_policy ON public.orders;
DROP POLICY IF EXISTS orders_insert_policy ON public.orders;
DROP POLICY IF EXISTS orders_delete_policy ON public.orders;
DROP POLICY IF EXISTS orders_aud_select_policy ON public.orders_aud;
DROP POLICY IF EXISTS orders_aud_insert_policy ON public.orders_aud;
DROP POLICY IF EXISTS order_items_update_policy ON public.order_items;
DROP POLICY IF EXISTS order_items_select_policy ON public.order_items;
DROP POLICY IF EXISTS order_items_insert_policy ON public.order_items;
DROP POLICY IF EXISTS order_items_delete_policy ON public.order_items;
DROP POLICY IF EXISTS order_items_aud_select_policy ON public.order_items_aud;
DROP POLICY IF EXISTS order_items_aud_insert_policy ON public.order_items_aud;
DROP POLICY IF EXISTS financial_transactions_rls_policy ON public.financial_transactions;
DROP POLICY IF EXISTS financial_transactions_aud_select_policy ON public.financial_transactions_aud;
DROP POLICY IF EXISTS financial_transactions_aud_insert_policy ON public.financial_transactions_aud;
DROP POLICY IF EXISTS customers_update_policy ON public.customers;
DROP POLICY IF EXISTS customers_select_policy ON public.customers;
DROP POLICY IF EXISTS customers_insert_policy ON public.customers;
DROP POLICY IF EXISTS customers_delete_policy ON public.customers;
DROP POLICY IF EXISTS customers_aud_select_policy ON public.customers_aud;
DROP POLICY IF EXISTS customers_aud_insert_policy ON public.customers_aud;
ALTER TABLE IF EXISTS ONLY public.shops DROP CONSTRAINT IF EXISTS fk_shops_tenant;
ALTER TABLE IF EXISTS ONLY public.shops_aud DROP CONSTRAINT IF EXISTS fk_shops_aud_revinfo;
ALTER TABLE IF EXISTS ONLY public.products_aud DROP CONSTRAINT IF EXISTS fk_products_aud_revinfo;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fk_orders_tenant;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fk_orders_shop;
pg_dump: dropping FK CONSTRAINT shops_aud fk_shops_aud_revinfo
pg_dump: dropping FK CONSTRAINT products_aud fk_products_aud_revinfo
pg_dump: dropping FK CONSTRAINT orders fk_orders_tenant
pg_dump: dropping FK CONSTRAINT orders fk_orders_shop
pg_dump: dropping FK CONSTRAINT orders fk_orders_customer
pg_dump: dropping FK CONSTRAINT orders_aud fk_orders_aud_revinfo
pg_dump: dropping FK CONSTRAINT order_items fk_order_items_tenant
pg_dump: dropping FK CONSTRAINT order_items fk_order_items_product
pg_dump: dropping FK CONSTRAINT order_items fk_order_items_order
pg_dump: dropping FK CONSTRAINT order_items_aud fk_order_items_aud_revinfo
pg_dump: dropping FK CONSTRAINT financial_transactions_aud fk_financial_transactions_aud_revinfo
pg_dump: dropping FK CONSTRAINT customers fk_customers_tenant
pg_dump: dropping FK CONSTRAINT customers_aud fk_customers_aud_revinfo
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fk_orders_customer;
ALTER TABLE IF EXISTS ONLY public.orders_aud DROP CONSTRAINT IF EXISTS fk_orders_aud_revinfo;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS fk_order_items_tenant;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS fk_order_items_product;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS fk_order_items_order;
ALTER TABLE IF EXISTS ONLY public.order_items_aud DROP CONSTRAINT IF EXISTS fk_order_items_aud_revinfo;
ALTER TABLE IF EXISTS ONLY public.financial_transactions_aud DROP CONSTRAINT IF EXISTS fk_financial_transactions_aud_revinfo;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS fk_customers_tenant;
ALTER TABLE IF EXISTS ONLY public.customers_aud DROP CONSTRAINT IF EXISTS fk_customers_aud_revinfo;
pg_dump: dropping TRIGGER orders update_orders_updated_at
pg_dump: dropping TRIGGER customers update_customers_updated_at
DROP TRIGGER IF EXISTS update_orders_updated_at ON public.orders;
DROP TRIGGER IF EXISTS update_customers_updated_at ON public.customers;
DROP INDEX IF EXISTS public.idx_shops_tenant_name;
pg_dump: dropping INDEX idx_shops_tenant_name
pg_dump: dropping INDEX idx_shops_tenant
pg_dump: dropping INDEX idx_shops_aud_tenant
pg_dump: dropping INDEX idx_shops_aud_rev
DROP INDEX IF EXISTS public.idx_shops_tenant;
DROP INDEX IF EXISTS public.idx_shops_aud_tenant;
DROP INDEX IF EXISTS public.idx_shops_aud_rev;
DROP INDEX IF EXISTS public.idx_revinfo_user;
DROP INDEX IF EXISTS public.idx_revinfo_tenant;
pg_dump: dropping INDEX idx_revinfo_user
pg_dump: dropping INDEX idx_revinfo_tenant
pg_dump: dropping INDEX idx_products_tenant_sku
pg_dump: dropping INDEX idx_products_tenant
pg_dump: dropping INDEX idx_products_aud_tenant
DROP INDEX IF EXISTS public.idx_products_tenant_sku;
DROP INDEX IF EXISTS public.idx_products_tenant;
DROP INDEX IF EXISTS public.idx_products_aud_tenant;
DROP INDEX IF EXISTS public.idx_products_aud_rev;
DROP INDEX IF EXISTS public.idx_orders_tenant;
DROP INDEX IF EXISTS public.idx_orders_status;
pg_dump: dropping INDEX idx_products_aud_rev
pg_dump: dropping INDEX idx_orders_tenant
pg_dump: dropping INDEX idx_orders_status
pg_dump: dropping INDEX idx_orders_shop
pg_dump: dropping INDEX idx_orders_number
pg_dump: dropping INDEX idx_orders_customer
pg_dump: dropping INDEX idx_orders_created
pg_dump: dropping INDEX idx_orders_aud_tenant
pg_dump: dropping INDEX idx_orders_aud_rev
pg_dump: dropping INDEX idx_orders_aud_customer
DROP INDEX IF EXISTS public.idx_orders_shop;
DROP INDEX IF EXISTS public.idx_orders_number;
DROP INDEX IF EXISTS public.idx_orders_customer;
DROP INDEX IF EXISTS public.idx_orders_created;
DROP INDEX IF EXISTS public.idx_orders_aud_tenant;
DROP INDEX IF EXISTS public.idx_orders_aud_rev;
pg_dump: dropping INDEX idx_order_items_tenant
pg_dump: dropping INDEX idx_order_items_product
pg_dump: DROP INDEX IF EXISTS public.idx_orders_aud_customer;
DROP INDEX IF EXISTS public.idx_order_items_tenant;
DROP INDEX IF EXISTS public.idx_order_items_product;
DROP INDEX IF EXISTS public.idx_order_items_order;
DROP INDEX IF EXISTS public.idx_order_items_aud_tenant;
DROP INDEX IF EXISTS public.idx_order_items_aud_rev;
dropping INDEX idx_order_items_order
pg_dump: dropping INDEX idx_order_items_aud_tenant
pg_dump: dropping INDEX idx_order_items_aud_rev
pg_dump: dropping INDEX idx_fin_tx_tenant
pg_dump: dropping INDEX idx_fin_tx_aud_tenant
DROP INDEX IF EXISTS public.idx_fin_tx_tenant;
DROP INDEX IF EXISTS public.idx_fin_tx_aud_tenant;
pg_dump: dropping INDEX idx_fin_tx_aud_rev
pg_dump: dropping INDEX idx_customers_tenant
DROP INDEX IF EXISTS public.idx_fin_tx_aud_rev;
DROP INDEX IF EXISTS public.idx_customers_tenant;
pg_dump: dropping INDEX idx_customers_phone
pg_dump: dropping INDEX idx_customers_email
DROP INDEX IF EXISTS public.idx_customers_phone;
DROP INDEX IF EXISTS public.idx_customers_email;
DROP INDEX IF EXISTS public.idx_customers_aud_tenant;
DROP INDEX IF EXISTS public.idx_customers_aud_rev;
DROP INDEX IF EXISTS public.flyway_schema_history_s_idx;
pg_dump: dropping INDEX idx_customers_aud_tenant
pg_dump: dropping INDEX idx_customers_aud_rev
pg_dump: dropping INDEX flyway_schema_history_s_idx
pg_dump: dropping CONSTRAINT orders uq_orders_tenant_number
pg_dump: dropping CONSTRAINT customers uq_customers_tenant_email
pg_dump: dropping CONSTRAINT orders uk_orders_order_number
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS uq_orders_tenant_number;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS uq_customers_tenant_email;
pg_dump: dropping CONSTRAINT tenants tenants_pkey
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS uk_orders_order_number;
pg_dump: dropping CONSTRAINT tenants tenants_name_key
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_pkey;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_name_key;
ALTER TABLE IF EXISTS ONLY public.shops DROP CONSTRAINT IF EXISTS shops_pkey;
ALTER TABLE IF EXISTS ONLY public.shops_aud DROP CONSTRAINT IF EXISTS shops_aud_pkey;
ALTER TABLE IF EXISTS ONLY public.revinfo DROP CONSTRAINT IF EXISTS revinfo_pkey;
pg_dump: dropping CONSTRAINT shops shops_pkey
pg_dump: dropping CONSTRAINT shops_aud shops_aud_pkey
pg_dump: dropping CONSTRAINT revinfo revinfo_pkey
pg_dump: dropping CONSTRAINT products products_pkey
pg_dump: dropping CONSTRAINT products_aud products_aud_pkey
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY public.products_aud DROP CONSTRAINT IF EXISTS products_aud_pkey;
pg_dump: dropping CONSTRAINT orders orders_pkey
pg_dump: dropping CONSTRAINT orders_aud orders_aud_pkey
pg_dump: dropping CONSTRAINT order_items order_items_pkey
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_pkey;
ALTER TABLE IF EXISTS ONLY public.orders_aud DROP CONSTRAINT IF EXISTS orders_aud_pkey;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_pkey;
ALTER TABLE IF EXISTS ONLY public.order_items_aud DROP CONSTRAINT IF EXISTS order_items_aud_pkey;
ALTER TABLE IF EXISTS ONLY public.flyway_schema_history DROP CONSTRAINT IF EXISTS flyway_schema_history_pk;
ALTER TABLE IF EXISTS ONLY public.financial_transactions DROP CONSTRAINT IF EXISTS financial_transactions_pkey;
pg_dump: dropping CONSTRAINT order_items_aud order_items_aud_pkey
pg_dump: dropping CONSTRAINT flyway_schema_history flyway_schema_history_pk
pg_dump: dropping CONSTRAINT financial_transactions financial_transactions_pkey
pg_dump: dropping CONSTRAINT financial_transactions_aud financial_transactions_aud_pkey
ALTER TABLE IF EXISTS ONLY public.financial_transactions_aud DROP CONSTRAINT IF EXISTS financial_transactions_aud_pkey;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_pkey;
pg_dump: dropping CONSTRAINT customers customers_pkey
pg_dump: dropping CONSTRAINT customers_aud customers_aud_pkey
pg_dump: dropping TABLE tenants
ALTER TABLE IF EXISTS ONLY public.customers_aud DROP CONSTRAINT IF EXISTS customers_aud_pkey;
DROP TABLE IF EXISTS public.tenants;
pg_dump: dropping TABLE shops_aud
pg_dump: dropping TABLE shops
pg_dump: dropping SEQUENCE revinfo_seq
pg_dump: dropping TABLE revinfo
pg_dump: dropping TABLE products_aud
pg_dump: dropping TABLE products
DROP TABLE IF EXISTS public.shops_aud;
DROP TABLE IF EXISTS public.shops;
DROP SEQUENCE IF EXISTS public.revinfo_seq;
DROP TABLE IF EXISTS public.revinfo;
DROP TABLE IF EXISTS public.products_aud;
DROP TABLE IF EXISTS public.products;
DROP TABLE IF EXISTS public.orders_aud;
pg_dump: dropping TABLE orders_aud
pg_dump: dropping TABLE orders
pg_dump: dropping TABLE order_items_aud
DROP TABLE IF EXISTS public.orders;
DROP TABLE IF EXISTS public.order_items_aud;
pg_dump: dropping TABLE order_items
pg_dump: dropping TABLE flyway_schema_history
DROP TABLE IF EXISTS public.order_items;
DROP TABLE IF EXISTS public.flyway_schema_history;
pg_dump: dropping TABLE financial_transactions_aud
pg_dump: dropping TABLE financial_transactions
pg_dump: dropping TABLE customers_aud
DROP TABLE IF EXISTS public.financial_transactions_aud;
DROP TABLE IF EXISTS public.financial_transactions;
pg_dump: dropping TABLE customers
pg_dump: dropping FUNCTION update_updated_at_column()
pg_dump: dropping FUNCTION update_customer_updated_at()
pg_dump: DROP TABLE IF EXISTS public.customers_aud;
DROP TABLE IF EXISTS public.customers;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP FUNCTION IF EXISTS public.update_customer_updated_at();
DROP FUNCTION IF EXISTS public.current_tenant_id();
dropping FUNCTION current_tenant_id()
pg_dump: dropping TYPE vat_rate_enum
pg_dump: dropping EXTENSION uuid-ossp
pg_dump: creating EXTENSION "uuid-ossp"
DROP TYPE IF EXISTS public.vat_rate_enum;
DROP EXTENSION IF EXISTS "uuid-ossp";
--
-- TOC entry 2 (class 3079 OID 16387)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


pg_dump: creating COMMENT "EXTENSION "uuid-ossp""
pg_dump: creating TYPE "public.vat_rate_enum"
pg_dump: creating FUNCTION "public.current_tenant_id()"
--
-- TOC entry 3650 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 869 (class 1247 OID 17989)
-- Name: vat_rate_enum; Type: TYPE; Schema: public; Owner: jtoye
--

CREATE TYPE public.vat_rate_enum AS ENUM (
    'ZERO',
    'REDUCED',
    'STANDARD',
    'EXEMPT'
);


ALTER TYPE public.vat_rate_enum OWNER TO jtoye;

pg_dump: creating FUNCTION "public.update_customer_updated_at()"
--
-- TOC entry 241 (class 1255 OID 17997)
-- Name: current_tenant_id(); Type: FUNCTION; Schema: public; Owner: jtoye
--

CREATE FUNCTION public.current_tenant_id() RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    v text;
BEGIN
    -- Try to get the setting; if it doesn't exist or is empty, return NULL
    BEGIN
        v := current_setting('app.current_tenant_id', true);
    EXCEPTION WHEN OTHERS THEN
        RETURN NULL;
    END;

    IF v IS NULL OR v = '' OR v = 'default' THEN
        RETURN NULL;
    END IF;
    RETURN v::uuid;
END;
$$;


ALTER FUNCTION public.current_tenant_id() OWNER TO jtoye;

--
-- TOC entry 243 (class 1255 OID 18275)
-- Name: update_customer_updated_at(); Type: FUNCTION; Schema: public; Owner: jtoye
--

CREATE FUNCTION public.update_customer_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customer_updated_at() OWNER TO jtoye;

--
-- TOC entry 242 (class 1255 OID 18212)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: jtoye
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO jtoye;

pg_dump: creating FUNCTION "public.update_updated_at_column()"
pg_dump: creating TABLE "public.customers"
pg_dump: creating COMMENT "public.TABLE customers"
pg_dump: creating COMMENT "public.COLUMN customers.allergen_restrictions"
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 229 (class 1259 OID 18234)
-- Name: customers; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.customers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(50),
    allergen_restrictions integer DEFAULT 0,
    notes text
);

ALTER TABLE ONLY public.customers FORCE ROW LEVEL SECURITY;


ALTER TABLE public.customers OWNER TO jtoye;

--
-- TOC entry 3651 (class 0 OID 0)
-- Dependencies: 229
-- Name: TABLE customers; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON TABLE public.customers IS 'Customer records with allergen tracking for safety compliance';


pg_dump: creating COMMENT "public.COLUMN customers.notes"
pg_dump: creating TABLE "public.customers_aud"
--
-- TOC entry 3652 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN customers.allergen_restrictions; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON COLUMN public.customers.allergen_restrictions IS 'Bitmask of allergen restrictions (matches Product.allergen_mask)';


--
-- TOC entry 3653 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN customers.notes; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON COLUMN public.customers.notes IS 'Additional customer notes, preferences, or special requirements';


pg_dump: creating TABLE "public.financial_transactions"
pg_dump: creating TABLE "public.financial_transactions_aud"
--
-- TOC entry 230 (class 1259 OID 18259)
-- Name: customers_aud; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.customers_aud (
    id uuid NOT NULL,
    rev integer NOT NULL,
    revtype smallint,
    tenant_id uuid,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name character varying(255),
    email character varying(255),
    phone character varying(50),
    allergen_restrictions integer,
    notes text
);


ALTER TABLE public.customers_aud OWNER TO jtoye;

--
-- TOC entry 219 (class 1259 OID 18033)
-- Name: financial_transactions; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.financial_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    amount_pennies bigint NOT NULL,
    reference text,
    vat_rate character varying(20) NOT NULL,
    CONSTRAINT financial_transactions_vat_rate_temp_check CHECK (((vat_rate)::text = ANY ((ARRAY['ZERO'::character varying, 'REDUCED'::character varying, 'STANDARD'::character varying, 'EXEMPT'::character varying])::text[])))
);

ALTER TABLE ONLY public.financial_transactions FORCE ROW LEVEL SECURITY;


ALTER TABLE public.financial_transactions OWNER TO jtoye;

--
-- TOC entry 224 (class 1259 OID 18080)
-- Name: financial_transactions_aud; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.financial_transactions_aud (
    id uuid NOT NULL,
    rev integer NOT NULL,
    revtype smallint,
    tenant_id uuid,
    created_at timestamp with time zone,
    amount_pennies bigint,
    vat_rate text,
    reference text
);


ALTER TABLE public.financial_transactions_aud OWNER TO jtoye;

--
-- TOC entry 215 (class 1259 OID 17979)
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO jtoye;

pg_dump: creating TABLE "public.flyway_schema_history"
pg_dump: creating TABLE "public.order_items"
pg_dump: creating COMMENT "public.TABLE order_items"
pg_dump: creating COMMENT "public.COLUMN order_items.unit_price_pennies"
--
-- TOC entry 226 (class 1259 OID 18143)
-- Name: order_items; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.order_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    order_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity integer NOT NULL,
    unit_price_pennies bigint NOT NULL,
    total_price_pennies bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT order_items_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE public.order_items OWNER TO jtoye;

--
-- TOC entry 3659 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE order_items; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON TABLE public.order_items IS 'Line items within orders (products, quantities, prices)';


pg_dump: creating COMMENT "public.COLUMN order_items.total_price_pennies"
--
-- TOC entry 3660 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN order_items.unit_price_pennies; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON COLUMN public.order_items.unit_price_pennies IS 'Price per unit in pennies at time of order';


--
-- TOC entry 3661 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN order_items.total_price_pennies; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON COLUMN public.order_items.total_price_pennies IS 'Total line item price (quantity * unit_price)';


pg_dump: creating TABLE "public.order_items_aud"
pg_dump: creating TABLE "public.orders"
pg_dump: creating COMMENT "public.TABLE orders"
--
-- TOC entry 228 (class 1259 OID 18194)
-- Name: order_items_aud; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.order_items_aud (
    id uuid NOT NULL,
    rev integer NOT NULL,
    revtype smallint,
    tenant_id uuid,
    order_id uuid,
    product_id uuid,
    quantity integer,
    unit_price_pennies bigint,
    total_price_pennies bigint,
    created_at timestamp with time zone
);


ALTER TABLE public.order_items_aud OWNER TO jtoye;

--
-- TOC entry 225 (class 1259 OID 18119)
-- Name: orders; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    order_number character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'DRAFT'::character varying NOT NULL,
    customer_name character varying(255),
    customer_email character varying(255),
    customer_phone character varying(50),
    notes text,
    total_amount_pennies bigint DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    customer_id uuid,
    CONSTRAINT orders_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'PENDING'::character varying, 'CONFIRMED'::character varying, 'PREPARING'::character varying, 'READY'::character varying, 'COMPLETED'::character varying, 'CANCELLED'::character varying])::text[])))
);


ALTER TABLE public.orders OWNER TO jtoye;

pg_dump: creating COMMENT "public.COLUMN orders.order_number"
pg_dump: creating COMMENT "public.COLUMN orders.total_amount_pennies"
--
-- TOC entry 3664 (class 0 OID 0)
-- Dependencies: 225
-- Name: TABLE orders; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON TABLE public.orders IS 'Customer orders with multi-tenant isolation via RLS';


--
-- TOC entry 3665 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN orders.order_number; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON COLUMN public.orders.order_number IS 'Unique order number generated at order creation';


--
-- TOC entry 3666 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN orders.total_amount_pennies; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON COLUMN public.orders.total_amount_pennies IS 'Total order amount in pennies (cents) to avoid floating point issues';


pg_dump: creating COMMENT "public.COLUMN orders.customer_id"
pg_dump: creating TABLE "public.orders_aud"
--
-- TOC entry 3667 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN orders.customer_id; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON COLUMN public.orders.customer_id IS 'Optional FK to customers table (nullable for backward compatibility)';


pg_dump: creating COMMENT "public.COLUMN orders_aud.customer_id"
pg_dump: creating TABLE "public.products"
--
-- TOC entry 227 (class 1259 OID 18182)
-- Name: orders_aud; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.orders_aud (
    id uuid NOT NULL,
    rev integer NOT NULL,
    revtype smallint,
    tenant_id uuid,
    shop_id uuid,
    order_number character varying(50),
    status character varying(20),
    customer_name character varying(255),
    customer_email character varying(255),
    customer_phone character varying(50),
    notes text,
    total_amount_pennies bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    customer_id uuid
);


ALTER TABLE public.orders_aud OWNER TO jtoye;

--
-- TOC entry 3669 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN orders_aud.customer_id; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON COLUMN public.orders_aud.customer_id IS 'Audit history of customer_id FK from orders table';


--
-- TOC entry 218 (class 1259 OID 18023)
-- Name: products; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.products (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sku text NOT NULL,
    title text NOT NULL,
    ingredients_text text NOT NULL,
    allergen_mask integer DEFAULT 0 NOT NULL,
    price_pennies bigint DEFAULT 1000 NOT NULL
);

ALTER TABLE ONLY public.products FORCE ROW LEVEL SECURITY;


ALTER TABLE public.products OWNER TO jtoye;

--
-- TOC entry 3671 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN products.price_pennies; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON COLUMN public.products.price_pennies IS 'Product price in pennies (e.g., 1000 = $10.00, 2500 = $25.00)';


pg_dump: creating COMMENT "public.COLUMN products.price_pennies"
pg_dump: creating TABLE "public.products_aud"
pg_dump: creating TABLE "public.revinfo"
pg_dump: creating COMMENT "public.TABLE revinfo"
--
-- TOC entry 223 (class 1259 OID 18068)
-- Name: products_aud; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.products_aud (
    id uuid NOT NULL,
    rev integer NOT NULL,
    revtype smallint,
    tenant_id uuid,
    created_at timestamp with time zone,
    sku text,
    title text,
    ingredients_text text,
    allergen_mask integer,
    price_pennies bigint
);


ALTER TABLE public.products_aud OWNER TO jtoye;

--
-- TOC entry 220 (class 1259 OID 18050)
-- Name: revinfo; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.revinfo (
    rev integer NOT NULL,
    revtstmp bigint,
    tenant_id uuid,
    user_id character varying(255)
);


ALTER TABLE public.revinfo OWNER TO jtoye;

--
-- TOC entry 3674 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE revinfo; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON TABLE public.revinfo IS 'Envers revision metadata with tenant and user context for audit compliance';


--
-- TOC entry 3675 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN revinfo.tenant_id; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON COLUMN public.revinfo.tenant_id IS 'Tenant ID captured from TenantContext at time of revision';


pg_dump: creating COMMENT "public.COLUMN revinfo.tenant_id"
pg_dump: creating COMMENT "public.COLUMN revinfo.user_id"
--
-- TOC entry 3676 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN revinfo.user_id; Type: COMMENT; Schema: public; Owner: jtoye
--

COMMENT ON COLUMN public.revinfo.user_id IS 'User ID from JWT subject claim, identifies who made the change';


--
-- TOC entry 221 (class 1259 OID 18055)
-- Name: revinfo_seq; Type: SEQUENCE; Schema: public; Owner: jtoye
--

CREATE SEQUENCE public.revinfo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.revinfo_seq OWNER TO jtoye;

pg_dump: creating SEQUENCE "public.revinfo_seq"
pg_dump: creating TABLE "public.shops"
pg_dump: creating TABLE "public.shops_aud"
--
-- TOC entry 217 (class 1259 OID 18009)
-- Name: shops; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.shops (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    name text NOT NULL,
    address text
);

ALTER TABLE ONLY public.shops FORCE ROW LEVEL SECURITY;


ALTER TABLE public.shops OWNER TO jtoye;

--
-- TOC entry 222 (class 1259 OID 18056)
-- Name: shops_aud; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.shops_aud (
    id uuid NOT NULL,
    rev integer NOT NULL,
    revtype smallint,
    tenant_id uuid,
    created_at timestamp with time zone,
    name text,
    address text
);


ALTER TABLE public.shops_aud OWNER TO jtoye;

pg_dump: creating TABLE "public.tenants"
--
-- TOC entry 216 (class 1259 OID 17998)
-- Name: tenants; Type: TABLE; Schema: public; Owner: jtoye
--

CREATE TABLE public.tenants (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.tenants OWNER TO jtoye;

--
-- TOC entry 3642 (class 0 OID 18234)
-- Dependencies: 229
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.customers (id, tenant_id, created_at, updated_at, name, email, phone, allergen_restrictions, notes) FROM stdin;
pg_dump: processing data for table "public.customers"
pg_dump: dumping contents of table "public.customers"
\.


--
-- TOC entry 3643 (class 0 OID 18259)
-- Dependencies: 230
-- Data for Name: customers_aud; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.customers_aud (id, rev, revtype, tenant_id, created_at, updated_at, name, email, phone, allergen_restrictions, notes) FROM stdin;
pg_dump: processing data for table "public.customers_aud"
pg_dump: dumping contents of table "public.customers_aud"
pg_dump: processing data for table "public.financial_transactions"
pg_dump: dumping contents of table "public.financial_transactions"
4f4f1bcb-2d93-4c94-ad3c-925a05f3e784	1	0	00000000-0000-0000-0000-000000000001	2025-12-31 01:42:59.736691+00	2025-12-31 01:42:59.708655+00	Docker Test Customer	docker@example.com	+1234567890	0	\N
4f4f1bcb-2d93-4c94-ad3c-925a05f3e784	2	1	00000000-0000-0000-0000-000000000001	2025-12-31 01:42:59.736691+00	2025-12-31 01:42:59.903479+00	Updated Docker Customer	updated@example.com	+9876543210	0	\N
4f4f1bcb-2d93-4c94-ad3c-925a05f3e784	3	2	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- TOC entry 3632 (class 0 OID 18033)
-- Dependencies: 219
-- Data for Name: financial_transactions; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.financial_transactions (id, tenant_id, created_at, amount_pennies, reference, vat_rate) FROM stdin;
\.


--
-- TOC entry 3637 (class 0 OID 18080)
-- Dependencies: 224
-- Data for Name: financial_transactions_aud; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.financial_transactions_aud (id, rev, revtype, tenant_id, created_at, amount_pennies, vat_rate, reference) FROM stdin;
pg_dump: processing data for table "public.financial_transactions_aud"
pg_dump: dumping contents of table "public.financial_transactions_aud"
\.


--
-- TOC entry 3628 (class 0 OID 17979)
-- Dependencies: 215
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
pg_dump: processing data for table "public.flyway_schema_history"
pg_dump: dumping contents of table "public.flyway_schema_history"
1	1	base schema	SQL	V1__base_schema.sql	-830110174	jtoye	2025-12-31 01:36:13.656288	60	t
2	2	rls policies	SQL	V2__rls_policies.sql	-530713035	jtoye	2025-12-31 01:36:13.74048	7	t
3	3	add unique constraints	SQL	V3__add_unique_constraints.sql	-1474688764	jtoye	2025-12-31 01:36:13.758148	8	t
4	4	envers audit tables	SQL	V4__envers_audit_tables.sql	1420476887	jtoye	2025-12-31 01:36:13.773473	55	t
5	5	orders	SQL	V5__orders.sql	200111426	jtoye	2025-12-31 01:36:13.837249	85	t
6	6	fix order status type	SQL	V6__fix_order_status_type.sql	321101476	jtoye	2025-12-31 01:36:13.932607	31	t
7	7	add product pricing	SQL	V7__add_product_pricing.sql	1460696402	jtoye	2025-12-31 01:36:13.969642	6	t
8	8	add tenant context to revinfo	SQL	V8__add_tenant_context_to_revinfo.sql	-1360598415	jtoye	2025-12-31 01:36:13.98145	9	t
9	9	customers	SQL	V9__customers.sql	-399452013	jtoye	2025-12-31 01:36:13.995548	48	t
10	10	add customer id to orders aud	SQL	V10__add_customer_id_to_orders_aud.sql	1620942731	jtoye	2025-12-31 01:36:14.049888	4	t
11	11	fix audit rls for deletes	SQL	V11__fix_audit_rls_for_deletes.sql	-1817809755	jtoye	2025-12-31 01:36:14.058897	2	t
12	12	convert vat rate to varchar	SQL	V12__convert_vat_rate_to_varchar.sql	-917595739	jtoye	2025-12-31 01:36:14.065843	2	t
13	13	seed default tenants	SQL	V13__seed_default_tenants.sql	-507651225	jtoye	2025-12-31 01:36:14.072715	1	t
\.


--
-- TOC entry 3639 (class 0 OID 18143)
-- Dependencies: 226
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.order_items (id, tenant_id, order_id, product_id, quantity, unit_price_pennies, total_price_pennies, created_at) FROM stdin;
pg_dump: processing data for table "public.order_items"
pg_dump: dumping contents of table "public.order_items"
aaa5af34-26ee-4d5d-8049-3b7b0c819686	00000000-0000-0000-0000-000000000001	a4ecbe5a-45b4-46a5-bb9e-f746c059971d	965e7d5b-43fb-4eda-96d0-4b773ecf8978	1	1000	1000	2025-12-31 02:22:47.94913+00
\.


--
-- TOC entry 3641 (class 0 OID 18194)
-- Dependencies: 228
-- Data for Name: order_items_aud; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.order_items_aud (id, rev, revtype, tenant_id, order_id, product_id, quantity, unit_price_pennies, total_price_pennies, created_at) FROM stdin;
pg_dump: processing data for table "public.order_items_aud"
pg_dump: dumping contents of table "public.order_items_aud"
pg_dump: processing data for table "public.orders"
pg_dump: dumping contents of table "public.orders"
aaa5af34-26ee-4d5d-8049-3b7b0c819686	6	0	00000000-0000-0000-0000-000000000001	a4ecbe5a-45b4-46a5-bb9e-f746c059971d	965e7d5b-43fb-4eda-96d0-4b773ecf8978	1	1000	1000	2025-12-31 02:22:47.94913+00
\.


--
-- TOC entry 3638 (class 0 OID 18119)
-- Dependencies: 225
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.orders (id, tenant_id, shop_id, order_number, status, customer_name, customer_email, customer_phone, notes, total_amount_pennies, created_at, updated_at, customer_id) FROM stdin;
a4ecbe5a-45b4-46a5-bb9e-f746c059971d	00000000-0000-0000-0000-000000000001	cfdd06f4-1fa4-4222-be7e-8b6bfd4483d0	ORD-0d1a27e4-ab43-43eb-956b-b29d377fb3b5	READY	ss	s.j@ma.com		\N	1000	2025-12-31 02:22:47.938183+00	2025-12-31 02:33:24.260524+00	\N
\.


--
-- TOC entry 3640 (class 0 OID 18182)
-- Dependencies: 227
-- Data for Name: orders_aud; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.orders_aud (id, rev, revtype, tenant_id, shop_id, order_number, status, customer_name, customer_email, customer_phone, notes, total_amount_pennies, created_at, updated_at, customer_id) FROM stdin;
pg_dump: processing data for table "public.orders_aud"
pg_dump: dumping contents of table "public.orders_aud"
a4ecbe5a-45b4-46a5-bb9e-f746c059971d	6	0	00000000-0000-0000-0000-000000000001	cfdd06f4-1fa4-4222-be7e-8b6bfd4483d0	ORD-0d1a27e4-ab43-43eb-956b-b29d377fb3b5	DRAFT	ss	s.j@ma.com		\N	1000	2025-12-31 02:22:47.938183+00	2025-12-31 02:22:47.909205+00	\N
a4ecbe5a-45b4-46a5-bb9e-f746c059971d	7	1	00000000-0000-0000-0000-000000000001	cfdd06f4-1fa4-4222-be7e-8b6bfd4483d0	ORD-0d1a27e4-ab43-43eb-956b-b29d377fb3b5	PENDING	ss	s.j@ma.com		\N	1000	2025-12-31 02:22:47.938183+00	2025-12-31 02:22:51.279862+00	\N
a4ecbe5a-45b4-46a5-bb9e-f746c059971d	8	1	00000000-0000-0000-0000-000000000001	cfdd06f4-1fa4-4222-be7e-8b6bfd4483d0	ORD-0d1a27e4-ab43-43eb-956b-b29d377fb3b5	CONFIRMED	ss	s.j@ma.com		\N	1000	2025-12-31 02:22:47.938183+00	2025-12-31 02:22:53.584645+00	\N
a4ecbe5a-45b4-46a5-bb9e-f746c059971d	9	1	00000000-0000-0000-0000-000000000001	cfdd06f4-1fa4-4222-be7e-8b6bfd4483d0	ORD-0d1a27e4-ab43-43eb-956b-b29d377fb3b5	PREPARING	ss	s.j@ma.com		\N	1000	2025-12-31 02:22:47.938183+00	2025-12-31 02:33:20.884245+00	\N
a4ecbe5a-45b4-46a5-bb9e-f746c059971d	10	1	00000000-0000-0000-0000-000000000001	cfdd06f4-1fa4-4222-be7e-8b6bfd4483d0	ORD-0d1a27e4-ab43-43eb-956b-b29d377fb3b5	READY	ss	s.j@ma.com		\N	1000	2025-12-31 02:22:47.938183+00	2025-12-31 02:33:24.264184+00	\N
\.


--
-- TOC entry 3631 (class 0 OID 18023)
-- Dependencies: 218
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.products (id, tenant_id, created_at, sku, title, ingredients_text, allergen_mask, price_pennies) FROM stdin;
pg_dump: processing data for table "public.products"
pg_dump: dumping contents of table "public.products"
pg_dump: processing data for table "public.products_aud"
pg_dump: dumping contents of table "public.products_aud"
965e7d5b-43fb-4eda-96d0-4b773ecf8978	00000000-0000-0000-0000-000000000001	2025-12-31 01:48:44.878591+00	PROD-009	Chicken TEST	test test fours tetrsdt 	1	1000
\.


--
-- TOC entry 3636 (class 0 OID 18068)
-- Dependencies: 223
-- Data for Name: products_aud; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.products_aud (id, rev, revtype, tenant_id, created_at, sku, title, ingredients_text, allergen_mask, price_pennies) FROM stdin;
pg_dump: processing data for table "public.revinfo"
pg_dump: dumping contents of table "public.revinfo"
965e7d5b-43fb-4eda-96d0-4b773ecf8978	4	0	00000000-0000-0000-0000-000000000001	2025-12-31 01:48:44.878591+00	PROD-009	Chicken TEST	test test fours tetrsdt 	1	1000
\.


--
-- TOC entry 3633 (class 0 OID 18050)
-- Dependencies: 220
-- Data for Name: revinfo; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.revinfo (rev, revtstmp, tenant_id, user_id) FROM stdin;
pg_dump: processing data for table "public.shops"
pg_dump: dumping contents of table "public.shops"
1	1767145379752	00000000-0000-0000-0000-000000000001	09739f46-4d79-4b6a-8709-99ef205d5d45
2	1767145379910	00000000-0000-0000-0000-000000000001	09739f46-4d79-4b6a-8709-99ef205d5d45
3	1767145380115	00000000-0000-0000-0000-000000000001	09739f46-4d79-4b6a-8709-99ef205d5d45
4	1767145724879	00000000-0000-0000-0000-000000000001	b24ef5ca-82d6-4cc6-900f-82db92e10ab7
5	1767145777730	00000000-0000-0000-0000-000000000001	b24ef5ca-82d6-4cc6-900f-82db92e10ab7
6	1767147767955	00000000-0000-0000-0000-000000000001	b24ef5ca-82d6-4cc6-900f-82db92e10ab7
7	1767147771288	00000000-0000-0000-0000-000000000001	b24ef5ca-82d6-4cc6-900f-82db92e10ab7
8	1767147773587	00000000-0000-0000-0000-000000000001	b24ef5ca-82d6-4cc6-900f-82db92e10ab7
9	1767148400911	00000000-0000-0000-0000-000000000001	b24ef5ca-82d6-4cc6-900f-82db92e10ab7
10	1767148404266	00000000-0000-0000-0000-000000000001	b24ef5ca-82d6-4cc6-900f-82db92e10ab7
\.


--
-- TOC entry 3630 (class 0 OID 18009)
-- Dependencies: 217
-- Data for Name: shops; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.shops (id, tenant_id, created_at, name, address) FROM stdin;
cfdd06f4-1fa4-4222-be7e-8b6bfd4483d0	00000000-0000-0000-0000-000000000001	2025-12-31 01:49:37.728684+00	main shop 202	63 lladedf stret
\.


--
-- TOC entry 3635 (class 0 OID 18056)
-- Dependencies: 222
-- Data for Name: shops_aud; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.shops_aud (id, rev, revtype, tenant_id, created_at, name, address) FROM stdin;
pg_dump: processing data for table "public.shops_aud"
pg_dump: dumping contents of table "public.shops_aud"
pg_dump: processing data for table "public.tenants"
pg_dump: dumping contents of table "public.tenants"
cfdd06f4-1fa4-4222-be7e-8b6bfd4483d0	5	0	00000000-0000-0000-0000-000000000001	2025-12-31 01:49:37.728684+00	main shop 202	63 lladedf stret
\.


--
-- TOC entry 3629 (class 0 OID 17998)
-- Dependencies: 216
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: jtoye
--

COPY public.tenants (id, created_at, name) FROM stdin;
00000000-0000-0000-0000-000000000001	2025-12-31 01:36:14.074171+00	Tenant A
00000000-0000-0000-0000-000000000002	2025-12-31 01:36:14.074171+00	Tenant B
\.


--
-- TOC entry 3682 (class 0 OID 0)
-- Dependencies: 221
-- Name: revinfo_seq; Type: SEQUENCE SET; Schema: public; Owner: jtoye
--

SELECT pg_catalog.setval('public.revinfo_seq', 10, true);


--
-- TOC entry 3428 (class 2606 OID 18265)
-- Name: customers_aud customers_aud_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.customers_aud
    ADD CONSTRAINT customers_aud_pkey PRIMARY KEY (id, rev);


pg_dump: executing SEQUENCE SET revinfo_seq
pg_dump: creating CONSTRAINT "public.customers_aud customers_aud_pkey"
pg_dump: creating CONSTRAINT "public.customers customers_pkey"
pg_dump: creating CONSTRAINT "public.financial_transactions_aud financial_transactions_aud_pkey"
pg_dump: creating CONSTRAINT "public.financial_transactions financial_transactions_pkey"
--
-- TOC entry 3421 (class 2606 OID 18244)
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- TOC entry 3391 (class 2606 OID 18086)
-- Name: financial_transactions_aud financial_transactions_aud_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.financial_transactions_aud
    ADD CONSTRAINT financial_transactions_aud_pkey PRIMARY KEY (id, rev);


pg_dump: creating CONSTRAINT "public.flyway_schema_history flyway_schema_history_pk"
pg_dump: creating CONSTRAINT "public.order_items_aud order_items_aud_pkey"
--
-- TOC entry 3376 (class 2606 OID 18041)
-- Name: financial_transactions financial_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_pkey PRIMARY KEY (id);


--
-- TOC entry 3361 (class 2606 OID 17986)
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- TOC entry 3419 (class 2606 OID 18198)
-- Name: order_items_aud order_items_aud_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.order_items_aud
    ADD CONSTRAINT order_items_aud_pkey PRIMARY KEY (id, rev);


pg_dump: creating CONSTRAINT "public.order_items order_items_pkey"
pg_dump: creating CONSTRAINT "public.orders_aud orders_aud_pkey"
--
-- TOC entry 3410 (class 2606 OID 18150)
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- TOC entry 3415 (class 2606 OID 18188)
-- Name: orders_aud orders_aud_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.orders_aud
    ADD CONSTRAINT orders_aud_pkey PRIMARY KEY (id, rev);


--
-- TOC entry 3401 (class 2606 OID 18130)
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.orders orders_pkey"
pg_dump: creating CONSTRAINT "public.products_aud products_aud_pkey"
pg_dump: creating CONSTRAINT "public.products products_pkey"
pg_dump: creating CONSTRAINT "public.revinfo revinfo_pkey"
--
-- TOC entry 3389 (class 2606 OID 18074)
-- Name: products_aud products_aud_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.products_aud
    ADD CONSTRAINT products_aud_pkey PRIMARY KEY (id, rev);


--
-- TOC entry 3374 (class 2606 OID 18032)
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- TOC entry 3381 (class 2606 OID 18054)
-- Name: revinfo revinfo_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.revinfo
    ADD CONSTRAINT revinfo_pkey PRIMARY KEY (rev);


pg_dump: creating CONSTRAINT "public.shops_aud shops_aud_pkey"
pg_dump: creating CONSTRAINT "public.shops shops_pkey"
--
-- TOC entry 3385 (class 2606 OID 18062)
-- Name: shops_aud shops_aud_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.shops_aud
    ADD CONSTRAINT shops_aud_pkey PRIMARY KEY (id, rev);


--
-- TOC entry 3370 (class 2606 OID 18017)
-- Name: shops shops_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT shops_pkey PRIMARY KEY (id);


--
-- TOC entry 3364 (class 2606 OID 18008)
-- Name: tenants tenants_name_key; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_name_key UNIQUE (name);


pg_dump: creating CONSTRAINT "public.tenants tenants_name_key"
pg_dump: creating CONSTRAINT "public.tenants tenants_pkey"
--
-- TOC entry 3366 (class 2606 OID 18006)
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.orders uk_orders_order_number"
pg_dump: creating CONSTRAINT "public.customers uq_customers_tenant_email"
pg_dump: creating CONSTRAINT "public.orders uq_orders_tenant_number"
--
-- TOC entry 3403 (class 2606 OID 18231)
-- Name: orders uk_orders_order_number; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT uk_orders_order_number UNIQUE (order_number);


--
-- TOC entry 3426 (class 2606 OID 18246)
-- Name: customers uq_customers_tenant_email; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT uq_customers_tenant_email UNIQUE (tenant_id, email);


--
-- TOC entry 3405 (class 2606 OID 18132)
-- Name: orders uq_orders_tenant_number; Type: CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT uq_orders_tenant_number UNIQUE (tenant_id, order_number);


pg_dump: creating INDEX "public.flyway_schema_history_s_idx"
pg_dump: creating INDEX "public.idx_customers_aud_rev"
pg_dump: creating INDEX "public.idx_customers_aud_tenant"
--
-- TOC entry 3362 (class 1259 OID 17987)
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- TOC entry 3429 (class 1259 OID 18271)
-- Name: idx_customers_aud_rev; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_customers_aud_rev ON public.customers_aud USING btree (rev);


--
-- TOC entry 3430 (class 1259 OID 18272)
-- Name: idx_customers_aud_tenant; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_customers_aud_tenant ON public.customers_aud USING btree (tenant_id);


pg_dump: creating INDEX "public.idx_customers_email"
pg_dump: creating INDEX "public.idx_customers_phone"
pg_dump: creating INDEX "public.idx_customers_tenant"
--
-- TOC entry 3422 (class 1259 OID 18253)
-- Name: idx_customers_email; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_customers_email ON public.customers USING btree (email);


--
-- TOC entry 3423 (class 1259 OID 18254)
-- Name: idx_customers_phone; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_customers_phone ON public.customers USING btree (phone);


--
-- TOC entry 3424 (class 1259 OID 18252)
-- Name: idx_customers_tenant; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_customers_tenant ON public.customers USING btree (tenant_id);


pg_dump: creating INDEX "public.idx_fin_tx_aud_rev"
pg_dump: creating INDEX "public.idx_fin_tx_aud_tenant"
pg_dump: creating INDEX "public.idx_fin_tx_tenant"
pg_dump: creating INDEX "public.idx_order_items_aud_rev"
--
-- TOC entry 3392 (class 1259 OID 18096)
-- Name: idx_fin_tx_aud_rev; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_fin_tx_aud_rev ON public.financial_transactions_aud USING btree (rev);


--
-- TOC entry 3393 (class 1259 OID 18097)
-- Name: idx_fin_tx_aud_tenant; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_fin_tx_aud_tenant ON public.financial_transactions_aud USING btree (tenant_id);


--
-- TOC entry 3377 (class 1259 OID 18044)
-- Name: idx_fin_tx_tenant; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_fin_tx_tenant ON public.financial_transactions USING btree (tenant_id);


--
-- TOC entry 3416 (class 1259 OID 18206)
-- Name: idx_order_items_aud_rev; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_order_items_aud_rev ON public.order_items_aud USING btree (rev);


pg_dump: creating INDEX "public.idx_order_items_aud_tenant"
--
-- TOC entry 3417 (class 1259 OID 18207)
-- Name: idx_order_items_aud_tenant; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_order_items_aud_tenant ON public.order_items_aud USING btree (tenant_id);


pg_dump: creating INDEX "public.idx_order_items_order"
pg_dump: creating INDEX "public.idx_order_items_product"
--
-- TOC entry 3406 (class 1259 OID 18172)
-- Name: idx_order_items_order; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_order_items_order ON public.order_items USING btree (order_id);


--
-- TOC entry 3407 (class 1259 OID 18173)
-- Name: idx_order_items_product; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_order_items_product ON public.order_items USING btree (product_id);


pg_dump: creating INDEX "public.idx_order_items_tenant"
pg_dump: creating INDEX "public.idx_orders_aud_customer"
--
-- TOC entry 3408 (class 1259 OID 18171)
-- Name: idx_order_items_tenant; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_order_items_tenant ON public.order_items USING btree (tenant_id);


--
-- TOC entry 3411 (class 1259 OID 18283)
-- Name: idx_orders_aud_customer; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_orders_aud_customer ON public.orders_aud USING btree (customer_id);


pg_dump: creating INDEX "public.idx_orders_aud_rev"
--
-- TOC entry 3412 (class 1259 OID 18204)
-- Name: idx_orders_aud_rev; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_orders_aud_rev ON public.orders_aud USING btree (rev);


--
-- TOC entry 3413 (class 1259 OID 18205)
-- Name: idx_orders_aud_tenant; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_orders_aud_tenant ON public.orders_aud USING btree (tenant_id);


pg_dump: creating INDEX "public.idx_orders_aud_tenant"
pg_dump: creating INDEX "public.idx_orders_created"
pg_dump: creating INDEX "public.idx_orders_customer"
--
-- TOC entry 3394 (class 1259 OID 18169)
-- Name: idx_orders_created; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_orders_created ON public.orders USING btree (created_at DESC);


pg_dump: creating INDEX "public.idx_orders_number"
pg_dump: creating INDEX "public.idx_orders_shop"
pg_dump: creating INDEX "public.idx_orders_status"
--
-- TOC entry 3395 (class 1259 OID 18282)
-- Name: idx_orders_customer; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_orders_customer ON public.orders USING btree (customer_id);


--
-- TOC entry 3396 (class 1259 OID 18170)
-- Name: idx_orders_number; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_orders_number ON public.orders USING btree (order_number);


--
-- TOC entry 3397 (class 1259 OID 18167)
-- Name: idx_orders_shop; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_orders_shop ON public.orders USING btree (shop_id);


pg_dump: creating INDEX "public.idx_orders_tenant"
--
-- TOC entry 3398 (class 1259 OID 18214)
-- Name: idx_orders_status; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_orders_status ON public.orders USING btree (status);


--
-- TOC entry 3399 (class 1259 OID 18166)
-- Name: idx_orders_tenant; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_orders_tenant ON public.orders USING btree (tenant_id);


pg_dump: creating INDEX "public.idx_products_aud_rev"
pg_dump: --
-- TOC entry 3386 (class 1259 OID 18094)
-- Name: idx_products_aud_rev; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_products_aud_rev ON public.products_aud USING btree (rev);


creating INDEX "public.idx_products_aud_tenant"
pg_dump: creating INDEX "public.idx_products_tenant"
--
-- TOC entry 3387 (class 1259 OID 18095)
-- Name: idx_products_aud_tenant; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_products_aud_tenant ON public.products_aud USING btree (tenant_id);


--
-- TOC entry 3371 (class 1259 OID 18043)
-- Name: idx_products_tenant; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_products_tenant ON public.products USING btree (tenant_id);


pg_dump: creating INDEX "public.idx_products_tenant_sku"
pg_dump: creating INDEX "public.idx_revinfo_tenant"
--
-- TOC entry 3372 (class 1259 OID 18048)
-- Name: idx_products_tenant_sku; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE UNIQUE INDEX idx_products_tenant_sku ON public.products USING btree (tenant_id, sku);


--
-- TOC entry 3378 (class 1259 OID 18232)
-- Name: idx_revinfo_tenant; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_revinfo_tenant ON public.revinfo USING btree (tenant_id);


--
-- TOC entry 3379 (class 1259 OID 18233)
-- Name: idx_revinfo_user; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_revinfo_user ON public.revinfo USING btree (user_id);


--
-- TOC entry 3382 (class 1259 OID 18092)
-- Name: idx_shops_aud_rev; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_shops_aud_rev ON public.shops_aud USING btree (rev);


pg_dump: creating INDEX "public.idx_revinfo_user"
pg_dump: creating INDEX "public.idx_shops_aud_rev"
pg_dump: creating INDEX "public.idx_shops_aud_tenant"
pg_dump: creating INDEX "public.idx_shops_tenant"
pg_dump: creating INDEX "public.idx_shops_tenant_name"
--
-- TOC entry 3383 (class 1259 OID 18093)
-- Name: idx_shops_aud_tenant; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_shops_aud_tenant ON public.shops_aud USING btree (tenant_id);


--
-- TOC entry 3367 (class 1259 OID 18042)
-- Name: idx_shops_tenant; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE INDEX idx_shops_tenant ON public.shops USING btree (tenant_id);


--
-- TOC entry 3368 (class 1259 OID 18049)
-- Name: idx_shops_tenant_name; Type: INDEX; Schema: public; Owner: jtoye
--

CREATE UNIQUE INDEX idx_shops_tenant_name ON public.shops USING btree (tenant_id, name);


--
-- TOC entry 3446 (class 2620 OID 18276)
-- Name: customers update_customers_updated_at; Type: TRIGGER; Schema: public; Owner: jtoye
--

CREATE TRIGGER update_customers_updated_at BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.update_customer_updated_at();


--
-- TOC entry 3445 (class 2620 OID 18213)
-- Name: orders update_orders_updated_at; Type: TRIGGER; Schema: public; Owner: jtoye
--

CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


pg_dump: creating TRIGGER "public.customers update_customers_updated_at"
pg_dump: creating TRIGGER "public.orders update_orders_updated_at"
pg_dump: creating FK CONSTRAINT "public.customers_aud fk_customers_aud_revinfo"
--
-- TOC entry 3444 (class 2606 OID 18266)
-- Name: customers_aud fk_customers_aud_revinfo; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.customers_aud
    ADD CONSTRAINT fk_customers_aud_revinfo FOREIGN KEY (rev) REFERENCES public.revinfo(rev);


--
-- TOC entry 3443 (class 2606 OID 18247)
-- Name: customers fk_customers_tenant; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT fk_customers_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- TOC entry 3434 (class 2606 OID 18087)
-- Name: financial_transactions_aud fk_financial_transactions_aud_revinfo; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.financial_transactions_aud
    ADD CONSTRAINT fk_financial_transactions_aud_revinfo FOREIGN KEY (rev) REFERENCES public.revinfo(rev);


pg_dump: creating FK CONSTRAINT "public.customers fk_customers_tenant"
pg_dump: creating FK CONSTRAINT "public.financial_transactions_aud fk_financial_transactions_aud_revinfo"
pg_dump: creating FK CONSTRAINT "public.order_items_aud fk_order_items_aud_revinfo"
pg_dump: creating FK CONSTRAINT "public.order_items fk_order_items_order"
pg_dump: creating FK CONSTRAINT "public.order_items fk_order_items_product"
--
-- TOC entry 3442 (class 2606 OID 18199)
-- Name: order_items_aud fk_order_items_aud_revinfo; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.order_items_aud
    ADD CONSTRAINT fk_order_items_aud_revinfo FOREIGN KEY (rev) REFERENCES public.revinfo(rev);


--
-- TOC entry 3438 (class 2606 OID 18156)
-- Name: order_items fk_order_items_order; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- TOC entry 3439 (class 2606 OID 18161)
-- Name: order_items fk_order_items_product; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES public.products(id);


pg_dump: creating FK CONSTRAINT "public.order_items fk_order_items_tenant"
pg_dump: creating FK CONSTRAINT "public.orders_aud fk_orders_aud_revinfo"
pg_dump: creating FK CONSTRAINT "public.orders fk_orders_customer"
pg_dump: creating FK CONSTRAINT "public.orders fk_orders_shop"
pg_dump: creating FK CONSTRAINT "public.orders fk_orders_tenant"
--
-- TOC entry 3440 (class 2606 OID 18151)
-- Name: order_items fk_order_items_tenant; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fk_order_items_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- TOC entry 3441 (class 2606 OID 18189)
-- Name: orders_aud fk_orders_aud_revinfo; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.orders_aud
    ADD CONSTRAINT fk_orders_aud_revinfo FOREIGN KEY (rev) REFERENCES public.revinfo(rev);


--
-- TOC entry 3435 (class 2606 OID 18277)
-- Name: orders fk_orders_customer; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- TOC entry 3436 (class 2606 OID 18138)
-- Name: orders fk_orders_shop; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_orders_shop FOREIGN KEY (shop_id) REFERENCES public.shops(id);


--
-- TOC entry 3437 (class 2606 OID 18133)
-- Name: orders fk_orders_tenant; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_orders_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- TOC entry 3433 (class 2606 OID 18075)
-- Name: products_aud fk_products_aud_revinfo; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.products_aud
    ADD CONSTRAINT fk_products_aud_revinfo FOREIGN KEY (rev) REFERENCES public.revinfo(rev);


--
-- TOC entry 3432 (class 2606 OID 18063)
-- Name: shops_aud fk_shops_aud_revinfo; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.shops_aud
    ADD CONSTRAINT fk_shops_aud_revinfo FOREIGN KEY (rev) REFERENCES public.revinfo(rev);


pg_dump: creating FK CONSTRAINT "public.products_aud fk_products_aud_revinfo"
pg_dump: creating FK CONSTRAINT "public.shops_aud fk_shops_aud_revinfo"
pg_dump: creating FK CONSTRAINT "public.shops fk_shops_tenant"
--
-- TOC entry 3431 (class 2606 OID 18018)
-- Name: shops fk_shops_tenant; Type: FK CONSTRAINT; Schema: public; Owner: jtoye
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT fk_shops_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- TOC entry 3599 (class 0 OID 18234)
-- Dependencies: 229
-- Name: customers; Type: ROW SECURITY; Schema: public; Owner: jtoye
--

ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

pg_dump: creating ROW SECURITY "public.customers"
pg_dump: creating ROW SECURITY "public.customers_aud"
pg_dump: creating POLICY "public.customers_aud customers_aud_insert_policy"
pg_dump: creating POLICY "public.customers_aud customers_aud_select_policy"
pg_dump: creating POLICY "public.customers customers_delete_policy"
pg_dump: creating POLICY "public.customers customers_insert_policy"
pg_dump: creating POLICY "public.customers customers_select_policy"
--
-- TOC entry 3600 (class 0 OID 18259)
-- Dependencies: 230
-- Name: customers_aud; Type: ROW SECURITY; Schema: public; Owner: jtoye
--

ALTER TABLE public.customers_aud ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3624 (class 3256 OID 18274)
-- Name: customers_aud customers_aud_insert_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY customers_aud_insert_policy ON public.customers_aud FOR INSERT WITH CHECK (true);


--
-- TOC entry 3623 (class 3256 OID 18273)
-- Name: customers_aud customers_aud_select_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY customers_aud_select_policy ON public.customers_aud FOR SELECT USING ((tenant_id = public.current_tenant_id()));


--
-- TOC entry 3622 (class 3256 OID 18258)
-- Name: customers customers_delete_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY customers_delete_policy ON public.customers FOR DELETE USING (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


--
-- TOC entry 3620 (class 3256 OID 18256)
-- Name: customers customers_insert_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY customers_insert_policy ON public.customers FOR INSERT WITH CHECK (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


--
-- TOC entry 3619 (class 3256 OID 18255)
-- Name: customers customers_select_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY customers_select_policy ON public.customers FOR SELECT USING (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


pg_dump: creating POLICY "public.customers customers_update_policy"
pg_dump: creating ROW SECURITY "public.financial_transactions"
pg_dump: creating ROW SECURITY "public.financial_transactions_aud"
--
-- TOC entry 3621 (class 3256 OID 18257)
-- Name: customers customers_update_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY customers_update_policy ON public.customers FOR UPDATE USING (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))) WITH CHECK (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


--
-- TOC entry 3591 (class 0 OID 18033)
-- Dependencies: 219
-- Name: financial_transactions; Type: ROW SECURITY; Schema: public; Owner: jtoye
--

ALTER TABLE public.financial_transactions ENABLE ROW LEVEL SECURITY;

pg_dump: creating POLICY "public.financial_transactions_aud financial_transactions_aud_insert_policy"
pg_dump: creating POLICY "public.financial_transactions_aud financial_transactions_aud_select_policy"
pg_dump: creating POLICY "public.financial_transactions financial_transactions_rls_policy"
pg_dump: creating ROW SECURITY "public.order_items"
pg_dump: creating ROW SECURITY "public.order_items_aud"
--
-- TOC entry 3594 (class 0 OID 18080)
-- Dependencies: 224
-- Name: financial_transactions_aud; Type: ROW SECURITY; Schema: public; Owner: jtoye
--

ALTER TABLE public.financial_transactions_aud ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3627 (class 3256 OID 18286)
-- Name: financial_transactions_aud financial_transactions_aud_insert_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY financial_transactions_aud_insert_policy ON public.financial_transactions_aud FOR INSERT WITH CHECK (true);


--
-- TOC entry 3606 (class 3256 OID 18102)
-- Name: financial_transactions_aud financial_transactions_aud_select_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY financial_transactions_aud_select_policy ON public.financial_transactions_aud FOR SELECT USING ((tenant_id = public.current_tenant_id()));


--
-- TOC entry 3603 (class 3256 OID 18047)
-- Name: financial_transactions financial_transactions_rls_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY financial_transactions_rls_policy ON public.financial_transactions USING ((tenant_id = public.current_tenant_id())) WITH CHECK ((tenant_id = public.current_tenant_id()));


--
-- TOC entry 3596 (class 0 OID 18143)
-- Dependencies: 226
-- Name: order_items; Type: ROW SECURITY; Schema: public; Owner: jtoye
--

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3598 (class 0 OID 18194)
-- Dependencies: 228
-- Name: order_items_aud; Type: ROW SECURITY; Schema: public; Owner: jtoye
--

ALTER TABLE public.order_items_aud ENABLE ROW LEVEL SECURITY;

pg_dump: creating POLICY "public.order_items_aud order_items_aud_insert_policy"
--
-- TOC entry 3618 (class 3256 OID 18211)
-- Name: order_items_aud order_items_aud_insert_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY order_items_aud_insert_policy ON public.order_items_aud FOR INSERT WITH CHECK (true);


--
-- TOC entry 3610 (class 3256 OID 18210)
-- Name: order_items_aud order_items_aud_select_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY order_items_aud_select_policy ON public.order_items_aud FOR SELECT USING ((tenant_id = public.current_tenant_id()));


pg_dump: creating POLICY "public.order_items_aud order_items_aud_select_policy"
pg_dump: creating POLICY "public.order_items order_items_delete_policy"
pg_dump: creating POLICY "public.order_items order_items_insert_policy"
--
-- TOC entry 3616 (class 3256 OID 18181)
-- Name: order_items order_items_delete_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY order_items_delete_policy ON public.order_items FOR DELETE USING (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


--
-- TOC entry 3614 (class 3256 OID 18179)
-- Name: order_items order_items_insert_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY order_items_insert_policy ON public.order_items FOR INSERT WITH CHECK (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


pg_dump: creating POLICY "public.order_items order_items_select_policy"
pg_dump: creating POLICY "public.order_items order_items_update_policy"
pg_dump:--
-- TOC entry 3613 (class 3256 OID 18178)
-- Name: order_items order_items_select_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY order_items_select_policy ON public.order_items FOR SELECT USING (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


--
-- TOC entry 3615 (class 3256 OID 18180)
-- Name: order_items order_items_update_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY order_items_update_policy ON public.order_items FOR UPDATE USING (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))) WITH CHECK (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


 creating ROW SECURITY "public.orders"
pg_dump: creating ROW SECURITY "public.orders_aud"
pg_dump: creating POLICY "public.orders_aud orders_aud_insert_policy"
pg_dump: creating POLICY "public.orders_aud orders_aud_select_policy"
pg_dump: creating POLICY "public.orders orders_delete_policy"
pg_dump: creating POLICY "public.orders orders_insert_policy"
--
-- TOC entry 3595 (class 0 OID 18119)
-- Dependencies: 225
-- Name: orders; Type: ROW SECURITY; Schema: public; Owner: jtoye
--

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3597 (class 0 OID 18182)
-- Dependencies: 227
-- Name: orders_aud; Type: ROW SECURITY; Schema: public; Owner: jtoye
--

ALTER TABLE public.orders_aud ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3609 (class 3256 OID 18209)
-- Name: orders_aud orders_aud_insert_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY orders_aud_insert_policy ON public.orders_aud FOR INSERT WITH CHECK (true);


--
-- TOC entry 3617 (class 3256 OID 18208)
-- Name: orders_aud orders_aud_select_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY orders_aud_select_policy ON public.orders_aud FOR SELECT USING ((tenant_id = public.current_tenant_id()));


--
-- TOC entry 3612 (class 3256 OID 18177)
-- Name: orders orders_delete_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY orders_delete_policy ON public.orders FOR DELETE USING (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


--
-- TOC entry 3608 (class 3256 OID 18175)
-- Name: orders orders_insert_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY orders_insert_policy ON public.orders FOR INSERT WITH CHECK (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


pg_dump: creating POLICY "public.orders orders_select_policy"
pg_dump: creating POLICY "public.orders orders_update_policy"
--
-- TOC entry 3607 (class 3256 OID 18174)
-- Name: orders orders_select_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY orders_select_policy ON public.orders FOR SELECT USING (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


--
-- TOC entry 3611 (class 3256 OID 18176)
-- Name: orders orders_update_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY orders_update_policy ON public.orders FOR UPDATE USING (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))) WITH CHECK (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


pg_dump: creating ROW SECURITY "public.products"
pg_dump: creating ROW SECURITY "public.products_aud"
pg_dump: creating POLICY "public.products_aud products_aud_insert_policy"
pg_dump: creating POLICY "public.products_aud products_aud_select_policy"
--
-- TOC entry 3590 (class 0 OID 18023)
-- Dependencies: 218
-- Name: products; Type: ROW SECURITY; Schema: public; Owner: jtoye
--

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3593 (class 0 OID 18068)
-- Dependencies: 223
-- Name: products_aud; Type: ROW SECURITY; Schema: public; Owner: jtoye
--

ALTER TABLE public.products_aud ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3626 (class 3256 OID 18285)
-- Name: products_aud products_aud_insert_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY products_aud_insert_policy ON public.products_aud FOR INSERT WITH CHECK (true);


--
-- TOC entry 3605 (class 3256 OID 18100)
-- Name: products_aud products_aud_select_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY products_aud_select_policy ON public.products_aud FOR SELECT USING ((tenant_id = public.current_tenant_id()));


pg_dump: creating POLICY "public.products products_rls_policy"
pg_dump: --
-- TOC entry 3602 (class 3256 OID 18046)
-- Name: products products_rls_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY products_rls_policy ON public.products USING ((tenant_id = public.current_tenant_id())) WITH CHECK ((tenant_id = public.current_tenant_id()));


--
-- TOC entry 3589 (class 0 OID 18009)
-- Dependencies: 217
-- Name: shops; Type: ROW SECURITY; Schema: public; Owner: jtoye
--

ALTER TABLE public.shops ENABLE ROW LEVEL SECURITY;

creating ROW SECURITY "public.shops"
pg_dump: creating ROW SECURITY "public.shops_aud"
--
-- TOC entry 3592 (class 0 OID 18056)
-- Dependencies: 222
-- Name: shops_aud; Type: ROW SECURITY; Schema: public; Owner: jtoye
--

ALTER TABLE public.shops_aud ENABLE ROW LEVEL SECURITY;

pg_dump: creating POLICY "public.shops_aud shops_aud_insert_policy"
pg_dump: creating POLICY "public.shops_aud shops_aud_select_policy"
--
-- TOC entry 3625 (class 3256 OID 18284)
-- Name: shops_aud shops_aud_insert_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY shops_aud_insert_policy ON public.shops_aud FOR INSERT WITH CHECK (true);


--
-- TOC entry 3604 (class 3256 OID 18098)
-- Name: shops_aud shops_aud_select_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY shops_aud_select_policy ON public.shops_aud FOR SELECT USING ((tenant_id = public.current_tenant_id()));


pg_dump: creating POLICY "public.shops shops_rls_policy"
pg_dump: creating ACL "SCHEMA public"
--
-- TOC entry 3601 (class 3256 OID 18045)
-- Name: shops shops_rls_policy; Type: POLICY; Schema: public; Owner: jtoye
--

CREATE POLICY shops_rls_policy ON public.shops USING ((tenant_id = public.current_tenant_id())) WITH CHECK ((tenant_id = public.current_tenant_id()));


--
-- TOC entry 3649 (class 0 OID 0)
-- Dependencies: 6
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO jtoye_app;


--
-- TOC entry 3654 (class 0 OID 0)
-- Dependencies: 229
-- Name: TABLE customers; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.customers TO jtoye_app;


--
-- TOC entry 3655 (class 0 OID 0)
-- Dependencies: 230
-- Name: TABLE customers_aud; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.customers_aud TO jtoye_app;


--
-- TOC entry 3656 (class 0 OID 0)
-- Dependencies: 219
-- Name: TABLE financial_transactions; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.financial_transactions TO jtoye_app;


pg_dump: creating ACL "public.TABLE customers"
pg_dump: creating ACL "public.TABLE customers_aud"
pg_dump: creating ACL "public.TABLE financial_transactions"
pg_dump: creating ACL "public.TABLE financial_transactions_aud"
pg_dump: creating ACL "public.TABLE flyway_schema_history"
--
-- TOC entry 3657 (class 0 OID 0)
-- Dependencies: 224
-- Name: TABLE financial_transactions_aud; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.financial_transactions_aud TO jtoye_app;


--
-- TOC entry 3658 (class 0 OID 0)
-- Dependencies: 215
-- Name: TABLE flyway_schema_history; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.flyway_schema_history TO jtoye_app;


pg_dump: creating ACL "public.TABLE order_items"
pg_dump: creating ACL "public.TABLE order_items_aud"
--
-- TOC entry 3662 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE order_items; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.order_items TO jtoye_app;


--
-- TOC entry 3663 (class 0 OID 0)
-- Dependencies: 228
-- Name: TABLE order_items_aud; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.order_items_aud TO jtoye_app;


pg_dump: creating ACL "public.TABLE orders"
pg_dump: creating ACL "public.TABLE orders_aud"
--
-- TOC entry 3668 (class 0 OID 0)
-- Dependencies: 225
-- Name: TABLE orders; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.orders TO jtoye_app;


--
-- TOC entry 3670 (class 0 OID 0)
-- Dependencies: 227
-- Name: TABLE orders_aud; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.orders_aud TO jtoye_app;


pg_dump: creating ACL "public.TABLE products"
pg_dump: creating ACL "public.TABLE products_aud"
pg_dump: creating ACL "public.TABLE revinfo"
pg_dump: creating ACL "public.SEQUENCE revinfo_seq"
pg_dump:--
-- TOC entry 3672 (class 0 OID 0)
-- Dependencies: 218
-- Name: TABLE products; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.products TO jtoye_app;


--
-- TOC entry 3673 (class 0 OID 0)
-- Dependencies: 223
-- Name: TABLE products_aud; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.products_aud TO jtoye_app;


--
-- TOC entry 3677 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE revinfo; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.revinfo TO jtoye_app;


--
-- TOC entry 3678 (class 0 OID 0)
-- Dependencies: 221
-- Name: SEQUENCE revinfo_seq; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON SEQUENCE public.revinfo_seq TO jtoye_app;


--
-- TOC entry 3679 (class 0 OID 0)
-- Dependencies: 217
-- Name: TABLE shops; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.shops TO jtoye_app;


 creating ACL "public.TABLE shops"
pg_dump: creating ACL "public.TABLE shops_aud"
--
-- TOC entry 3680 (class 0 OID 0)
-- Dependencies: 222
-- Name: TABLE shops_aud; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.shops_aud TO jtoye_app;


pg_dump: creating ACL "public.TABLE tenants"
pg_dump: creating DEFAULT ACL "public.DEFAULT PRIVILEGES FOR SEQUENCES"
pg_dump: creating DEFAULT ACL "public.DEFAULT PRIVILEGES FOR TABLES"
--
-- TOC entry 3681 (class 0 OID 0)
-- Dependencies: 216
-- Name: TABLE tenants; Type: ACL; Schema: public; Owner: jtoye
--

GRANT ALL ON TABLE public.tenants TO jtoye_app;


--
-- TOC entry 2109 (class 826 OID 16399)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: jtoye
--

ALTER DEFAULT PRIVILEGES FOR ROLE jtoye IN SCHEMA public GRANT ALL ON SEQUENCES  TO jtoye_app;


--
-- TOC entry 2108 (class 826 OID 16398)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: jtoye
--

ALTER DEFAULT PRIVILEGES FOR ROLE jtoye IN SCHEMA public GRANT ALL ON TABLES  TO jtoye_app;


-- Completed on 2025-12-31 12:02:49 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict MOFAQiLAqZgwhPBKUj7DtCXofGYuAeVaSa9zDNYLe0EEdIZYION0JBG09Z4YNrA

